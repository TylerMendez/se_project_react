import React from 'react';

function Footer() {
  return (
    <footer className="footer">
      <p>© Developed by Tyler Mendez 2025</p>
    </footer>
  );
}

export default Footer;